<?php
require_once __DIR__ . "/../../helpers/auth.php";
require_once __DIR__ . "/../../helpers/pagination.php";
require_once __DIR__ . "/../../repositories/book-repository.php";
require_once __DIR__ . "/../../repositories/category-repository.php";

requireLogin();

// Filter dari query string (?search=...&category=...&page=...)
$search = trim($_GET['search'] ?? '');
$category = trim($_GET['category'] ?? '');

$pagination = paginate(getBooks($search, $category), currentPage());
$books = $pagination['data'];
$categories = getCategories();

$pageTitle = "Manajemen Buku";
$pageSubtitle = "Kelola data buku, kategori, dan penulis";
?>

<!DOCTYPE html>
<html lang="id">

<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Manajemen Buku - Perpustakaan Digital</title>
  <link rel="stylesheet" href="../../styles/books/index.css">
</head>

<body>
  <div class="app-shell">
    <?php require_once __DIR__ . "/../../components/admin/sidebar.php" ?>

    <main class="app-main">
      <?php require_once __DIR__ . "/../../components/admin/topbar.php" ?>

      <div class="app-content">
        <?php require_once __DIR__ . "/../../components/admin/alert.php" ?>

        <div class="toolbar">
          <form method="GET" action="" class="toolbar-filters">
            <div class="search-box">
              <svg class="icon" width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor"
                stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <circle cx="11" cy="11" r="7" />
                <path d="m21 21-4.3-4.3" />
              </svg>
              <input type="text" name="search" class="search-input" placeholder="Cari judul buku..." value="<?= e($search) ?>">
            </div>
            <select name="category" class="filter-select">
              <option value="">Semua Kategori</option>
              <?php foreach ($categories as $cat): ?>
                <option value="<?= e($cat['name']) ?>" <?= $category === $cat['name'] ? 'selected' : '' ?>><?= e($cat['name']) ?></option>
              <?php endforeach; ?>
            </select>
            <button type="submit" class="btn btn-outline btn-sm">Cari</button>
          </form>
          <?php if (isAdmin()): ?>
            <a href="create.php" class="btn btn-primary">+ Tambah Buku</a>
          <?php endif; ?>
        </div>

        <div class="data-card">
          <table class="data-table">
            <thead>
              <tr>
                <th>Judul Buku</th>
                <th>Kategori</th>
                <th>Penulis</th>
                <th>Stok</th>
                <th>Aksi</th>
              </tr>
            </thead>
            <tbody>
              <?php foreach ($books as $index => $book): ?>
                <tr>
                  <td>
                    <div class="cell-primary">
                      <span class="cell-thumb"><svg class="icon" width="16" height="16" viewBox="0 0 24 24" fill="none"
                          stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                          <path d="M4 19.5A2.5 2.5 0 0 1 6.5 17H20" />
                          <path d="M6.5 2H20v20H6.5A2.5 2.5 0 0 1 4 19.5v-15A2.5 2.5 0 0 1 6.5 2Z" />
                        </svg></span>
                      <a href="show.php?id=<?= $book['id'] ?>" style="color:inherit;"><?= e($book['title']) ?></a>
                    </div>
                  </td>
                  <td><span class="badge badge-muted"><?= e($book['category']) ?></span></td>
                  <td>
                    <div class="chip-list">
                      <?php foreach ($book['authors'] as $author): ?>
                        <span class="chip">
                          <?= e($author) ?>
                        </span>
                      <?php endforeach ?>
                    </div>
                  </td>
                  <td><?= $book['stock'] ?></td>
                  <td>
                    <div class="cell-actions">
                      <a href="show.php?id=<?= $book['id'] ?>" class="btn btn-outline btn-sm">Detail</a>
                      <?php if (isAdmin()): ?>
                        <a href="edit.php?id=<?= $book['id'] ?>" class="btn btn-outline btn-sm">Edit</a>
                        <a href="../../actions/books/destroy.php?id=<?= $book['id'] ?>" class="btn btn-danger btn-sm"
                          onclick="return confirm('Yakin ingin menghapus buku ini?')">Hapus</a>
                      <?php endif; ?>
                    </div>
                  </td>
                </tr>
              <?php endforeach ?>
              <?php if (empty($books)): ?>
                <tr><td colspan="5" style="text-align:center;color:var(--ink-soft);">Tidak ada buku yang cocok dengan pencarian.</td></tr>
              <?php endif; ?>
            </tbody>
          </table>
        </div>

        <?php require_once __DIR__ . "/../../components/pagination.php" ?>
      </div>
    </main>
  </div>
</body>

</html>